<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_user extends CI_Model {

	public function tambah($isi)
	{
		return $this->db->insert('tb_user', $isi);
	}

}

/* End of file M_user.php */
/* Location: ./application/modules/users/models/M_user.php */