<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		if(empty($this->session->userdata('Admin'))){
			redirect('Login','refresh');

		}
		$this->load->model('M_user');
	}
	
	public function index()
	{
		$data['isi'] = $this->db->get('tb_user')->result(); //mengambil data dari tabel dalam database

		$data['home'] = 'admin/tabel_user';
		$data['judul'] = 'ServerPHB | Tabel User';
		$data['status'] = 'Tabel User';
		$this->load->view('admin/dashboard', $data);
	}

		public function input_user()
	{
		//fungsi untuk menampilkan view input data user
		$data['home'] = 'admin/form_user';
		$data['judul'] = 'ServerPHB | Form User';
		$data['status'] = 'Form Input User';
		$this->load->view('admin/dashboard', $data, FALSE);
	}

	public function tabel_user()
	{
		//fungsi untuk melihat view tabel user

		$data['isi'] = $this->db->get('tb_user')->result(); //mengambil data dari tabel dalam database

		$data['home'] = 'admin/tabel_user';
		$data['judul'] = 'ServerPHB | Tabel User';
		$data['status'] = 'Tabel User';
		$this->load->view('admin/dashboard', $data);
	}

	public function adduserpost()
	{
		//fungsi untuk mengepost hasil input data
		$u = $this->input->post('username');
		$p = md5($this->input->post('pw'));
		$n = $this->input->post('nama');
		$hp = $this->input->post('no_hp');
		$a = $this->input->post('alamat');
		$data = array('username' => $u ,
					  'password' => $p,
					  'nama' => $n,
					  'no_hp' => $hp,
				      'alamat' => $a);
		//Code untuk upload file
		$config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg|JPG';
                $config['max_size']             = 3024;
                $config['encrypt_name'] = TRUE;
                // code untuk max size khusus gambar
                // $config['max_width']            = 1024;
                // $config['max_height']           = 768;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('foto'))
                {
                        
                        echo $this->upload->display_errors();
                }
                else
                {
                        $upload_data = $this->upload->data();
                        
                        $data = array_merge($data, array("foto_user"=>$upload_data['file_name']));
                        
                }
		//code akhir upload file
		$insert = $this->M_user->tambah($data);
	
	echo ($insert) ? 'sukses' : 'gagal' ;

	//setelah selesai sukses langsung kembali ke view input data user
	// redirect('users/input_user','refresh');
	}

	public function edit_user($id)
	{
		//fungsi untuk edit data
		$this->db->where('Id_user', $id);
		$data['isi'] = $this->db->get('tb_user')->row();
		$data['home'] = 'admin/edit_user';
		$data['judul'] = 'ServerPHB | Tabel User';
		$data['status'] = 'Tabel User';
		$this->load->view('admin/dashboard', $data, FALSE);
	}

	public function edituserpost($id)
	{
		//fungsi untuk mengepost hasil edit data
		$u = $this->input->post('username');
		$p = md5($this->input->post('pw'));
		$n = $this->input->post('nama');
		$hp = $this->input->post('no_hp'); 
		$a = $this->input->post('alamat');
		$data = array('username' => $u ,
					  'password' => $p,
					  'nama' => $n,
					  'no_hp' => $hp,
				      'alamat' => $a);
		$this->db->where('Id_user', $id);
		$update =	$this->db->update('tb_user', $data);
		echo ($update) ? 'Sukses Edit' : 'Gagal Edit' ;

		//setelah selesai sukses langsung kembali ke view tabel user
		redirect('users/tabel_user','refresh');
	}

	public function delete($id)
	{
		//fungsi untuk menghapus data di dalam tabel user
		$this->db->where('Id_user', $id);
		$delete =	$this->db->delete('tb_user');
		echo ($delete) ? 'sukses' : 'gagal' ;

		//setelah selesai sukses langsung kembali ke view tabel user
		redirect('users/tabel_user','refresh');
	}

}

/* End of file user.php */
/* Location: ./application/modules/users/controllers/user.php */