<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_suhu extends CI_Model {

	public function getdata()
	{
		$this->db->order_by('id','DESC');
      $query = $this->db->get('tb_suhu');
      return $query->result();
	}

	function get_chart(){
		$this->db->select("tb_suhu.suhu,count(tb_suhu.id) as 'total'");
		$this->db->group_by('tb_suhu.id');
		$this->db->order_by('tb_suhu.id', 'desc');
		$query = $this->db->get('tb_suhu');
		return $query->result_array();
	}

	function report(){
        $query = $this->db->query("SELECT * from tb_suhu");
         
        if($query->num_rows() > 0){
            foreach($query->result() as $data){
                $hasil[] = $data;
            }
            return $hasil;
        }
    }

}

/* End of file M_suhu.php */
/* Location: ./application/modules/suhu/models/M_suhu.php */